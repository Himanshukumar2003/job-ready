import React from 'react'
import { IoIosStar } from "react-icons/io";
import { IoIosStarHalf } from "react-icons/io";
import { IoIosStarOutline } from "react-icons/io";
import BreadcrumbDesign from '../Breadcrumb/BreadcrumbDesign';
import Navbar from '../NavFoot/Navbar';
import { assests } from '../../assets/assets';

const CoursesCard = () => {
    const CourseCardMaping = [
        {
            id:1,
            CourseImage: "https://nicscomputer.com/photo/data-structure.webp",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        },
        {
            id:2,
            CourseImage: "https://www.classcentral.com/report/wp-content/uploads/2023/09/bcg_python_banner.png",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        },
        {
            id:3,
            CourseImage: "https://ultimatecourses.com/assets/share/courses/react-f02200115da09fd485a296e351972d7ea75701ed8d3d023d9f18c4b38e6b18b0.png",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        },
        {
            id:4,
            CourseImage: "https://www.classcentral.com/report/wp-content/uploads/2022/06/JavaScript-BCG-Banner-icons.png",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        },
        {
            id:5,
            CourseImage: "https://ultimatecourses.com/assets/share/courses/angular-39a525f3720f54d3fa1cbb19fdd14bd63bb33327569b6fc650001f66dbf2c8b9.png",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        },
        {
            id:6,
            CourseImage: "https://credencys.com/wp-content/uploads/2019/09/The-Complete-Node-js-Developer-Course.jpg",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        },
        {
            id:7,
            CourseImage: "https://fiverr-res.cloudinary.com/images/q_auto,f_auto/gigs/269190247/original/3dfbd605ac0d99de39db98133691afbcc5737496/develop-and-fix-mern-stack-websites.jpeg",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        },
        {
            id:8,
            CourseImage: "https://30dayscoding.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3pv3o0yr6pgj%2F1zxmh6ct5gjgaOJCvAjzzA%2F9395e9e8283b479bda4f00e51614586a%2FNExtJs_Fullstack.jpg&w=3840&q=75",
            CourseCategory: "Online Batch",
            CourseName: "Data Structure and Algorithms",
            CourseRate: "",
            CourseReviewRate: "4.3",
            CoursePrice: "₹1,499",
            CourseDiscountPrice:"₹2,599",
        }
    ]
  return (
    <div>
        <BreadcrumbDesign 
            BreadcrumbPara={'Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti laborum numquam ex animi autem dicta dolores est? Assumenda, tempora laudantium'} BreadCrumbImg={assests.BreadcrumbImage} 
            BreacrumbHeading={'What do you want to learn today?'}
        />

        <div className='py-10'>
            <div className='container'>
                <div className="grid grid-cols-12">
                    <div className="col-span-12 md:col-span-8">
                        <h2 className='lefttitle'>Recommended Courses</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus beatae, voluptatem corrupti nulla a minima ea dolorem mollitia illum nam, explicabo fuga, provident facilis quas maxime unde! Alias, enim quas.</p>
                    </div>
                </div>
                <div className="grid grid-cols-12 gap-x-0 md:gap-5 mt-10">
                    {CourseCardMaping.map((val)=>(
                        <div className="col-span-12 md:col-span-4 lg:col-span-3 mtb10 md:mtb-0">
                            <div className='border border-solid border-[#bdbdbd] overflow-hidden -rounded--theme-normalradius'>
                                <div className='h-40'><img className='-rounded-tr--theme-normalradius -rounded-tl--theme-normalradius h-full w-full object-cover' src={val.CourseImage} alt="" /></div>
                                <div className='-bg--theme-light -shadow--theme-lightshadow p20 -rounded-br--theme-normalradius -rounded-bl--theme-normalradius'>
                                    <span className='border border-solid -border--theme-primary-one -text--theme-primary-one p-1 rounded-sm -text--theme-xs mb10 inline-block'>{val.CourseCategory}</span>
                                    <h5 className='mb10 -font--theme-Extrabold -text--theme-sm line-clamp-1'>{val.CourseName}</h5>
                                    <div className='flex items-center gap-x-2 mb-1 -text--theme-primary-one'>
                                        <div className='flex items-center'>
                                            <IoIosStar/>
                                            <IoIosStar/>
                                            <IoIosStar/>
                                            <IoIosStarHalf/>
                                            <IoIosStarOutline/>
                                        </div>
                                        <div>{val.CourseReviewRate}</div>
                                    </div>
                                    <div className='flex items-center gap-x-2 mb10'>
                                        <span className='-font--theme-Extrabold'>{val.CoursePrice}</span>
                                        <span className='line-through'>{val.CourseDiscountPrice}</span>
                                    </div>
                                    <button className='darkbtn'>Register Now</button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
  )
}

export default CoursesCard
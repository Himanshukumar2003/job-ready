import React from 'react';

const LongTermsDetailsCard = ({ icon, name, year,  modules = [] }) => {
  return (
    <div className={`p30 h-full -rounded--theme-normalradius group border border-solid border-[#bdbdbd] transition-transform delay-75 ease-in-out group-hover:scale-90 group-hover:-translate-y-1 `}>
      <div className='mb20 min-w-20 w-20 h-20 -bg--theme-primary-one-light -rounded--theme-fullradius flex items-center justify-center'>
        <img className='w-12 transition-all delay-75 ease-in-out group-hover:scale-90 group-hover:-translate-y-1' src={icon} alt={name} />
      </div>
      <div>
        <h4 className='-font--theme-Extrabold -text--theme-sm mb10'>
          {name} {console.log(name)} <span className='-text--theme-primary-one'>{year} {console.log(year)}</span>
        </h4>
        <ul className='pl-0 md:pl-5'>
          {modules.length > 0 ? (
            modules.map((module, index) => (
              <li key={index}>{module} </li>
            ))
          ) : (
            <li>No Modules Available</li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default LongTermsDetailsCard;

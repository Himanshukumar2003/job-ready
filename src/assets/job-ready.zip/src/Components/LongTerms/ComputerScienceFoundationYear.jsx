import React from 'react'
import LongTermsCoursesCard from './LongTermsCoursesCard'
import { assests } from '../../assets/assets'
import BreadcrumbDesign from '../Breadcrumb/BreadcrumbDesign'
import ApplyNowForm from './ApplyNowForm'
import LongTermsDetailsCard from './LongTermsDetailsCard'

const ComputerScienceFoundationYear = () => {
    const LongTermsMaping = [
              {
                  id:1,
                  LongCoursesIcons: assests.computerscience,
                  LongCoursesName: "BSc (Hons) Computer Science with Foundation Year",
                  LongCoursesSpan: "Year 1 Modules",
                  LongCoursesList: [
                    {LongCoursesInnerList: "Communication and Study skills"},
                    {LongCoursesInnerList: "Foundation Mathematics I Foundation Mathematics II"},
                    {LongCoursesInnerList: "Fundamentals of Computing"},
                    {LongCoursesInnerList: "Practical Engineering Science for Electro-Mechanical Design"},
                    {LongCoursesInnerList: "Problem Solving in Science and Technology"}
                  ],
              },
              {
                  id:2,
                  LongCoursesIcons: assests.computerscience,
                  LongCoursesName: "BSc (Hons) Computer Science with Foundation Year",
                  LongCoursesSpan: "Year 2 Modules",
                  LongCoursesList: [
                    {LongCoursesInnerList: "Computational Mathematics"},
                    {LongCoursesInnerList: "Fundamentals of Computing"},
                    {LongCoursesInnerList: "Interactive 3D Applications and Academic Skills"},
                    {LongCoursesInnerList: "Internet Software Architecture and databases"},
                    {LongCoursesInnerList: "Introduction to object-oriented Programming"},
                    {LongCoursesInnerList: "Introductory Programming and Problem Solving"}
                  ],
              },
              {
                  id:3,
                  LongCoursesIcons: assests.computerscience,
                  LongCoursesName: "BSc (Hons) Computer Science with Foundation Year",
                  LongCoursesSpan: "Year 3 Modules",
                  LongCoursesList: [
                    {LongCoursesInnerList: "Algorithms and Concurrency Collaborative Development"},
                    {LongCoursesInnerList: "Full stack Development"},
                    {LongCoursesInnerList: "Object-Oriented Design and Programming"},
                    {LongCoursesInnerList: "Cloud Systems"},
                    {LongCoursesInnerList: "Computer Networking"},
                    {LongCoursesInnerList: "Concepts and Technologies of Al"},
                    {LongCoursesInnerList: "Data Mining"},
                    {LongCoursesInnerList: "Games and Interactive Applications Development"},
                  ],
              },
              {
                id:4,
                LongCoursesIcons: assests.computerscience,
                LongCoursesName: "BSc (Hons) Computer Science with Foundation Year",
                LongCoursesSpan: "Year 4 Modules",
                LongCoursesList: [
                    {LongCoursesInnerList: "Big Data"},
                    {LongCoursesInnerList: "Project and Professionalism"},
                    {LongCoursesInnerList: "Advanced Full Stack Development"},
                    {LongCoursesInnerList: "Advanced Games and Interactive Applications Development"},
                    {LongCoursesInnerList: "Artificial Intelligence and Machine Learning"},
                    {LongCoursesInnerList: "Intelligent Systems"},
                    {LongCoursesInnerList: "Mobile Application Design and Development"},
                    {LongCoursesInnerList: "Software Engineering"}
                ],
            }
          ]
  return (
    <>
        <BreadcrumbDesign 
            BreadCrumbImg={assests.BreadcrumbImage} 
            BreadcrumbPara={'Lorem ipsum dolor sit amet consectetur adipisicing elit.'} 
            BreacrumbHeading={`BSc (Hons) Computer Science with Foundation Year`}
        />
        <div className='ptb60'>
            <div className="container">
                <div className="grid grid-cols-12 gap-x-5">
                  <div className="col-span-12 md:col-span-9">
                    <div className="grid grid-cols-12 gap-x-5">
                      {LongTermsMaping.map((val)=>(
                        <div className="col-span-12 md:col-span-6 mb20" key={val.id}>
                          <LongTermsDetailsCard 
                          icon={val.LongCoursesIcons} 
                          name={val.LongCoursesName}
                          year={val.LongCoursesSpan}
                          modules={val.LongCoursesList? val.LongCoursesList.map((listval, index)=>(
                            <li key={index} className='list-decimal'>{listval.LongCoursesInnerList}</li>
                          )) : null}
                        />
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="col-span-12 md:col-span-3">
                      <ApplyNowForm/>
                  </div>
                </div>
            </div>
        </div>
    </>
  )
}

export default ComputerScienceFoundationYear
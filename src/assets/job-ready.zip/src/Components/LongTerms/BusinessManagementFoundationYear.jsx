import React from 'react'
import LongTermsCoursesCard from './LongTermsCoursesCard'
import { assests } from '../../assets/assets'
import BreadcrumbDesign from '../Breadcrumb/BreadcrumbDesign'
import ApplyNowForm from './ApplyNowForm'
import LongTermsDetailsCard from './LongTermsDetailsCard'
const BusinessManagementFoundationYear = () => {
  const LongTermsMaping = [
          {
              id:1,
              LongCoursesIcons: assests.businessmanagement,
              LongCoursesName: "BA (Hons) Business Management with Foundation Year",
              LongCoursesSpan: "Year 1 (Level 3) Modules",
              LongCoursesList: [
                {LongCoursesInnerList: "21st Century Management"},
                {LongCoursesInnerList: "Preparing for success at university"},
                {LongCoursesInnerList: "Principles of Business"},
                {LongCoursesInnerList: "Project-based learning"}
              ],
          },
          {
              id:2,
              LongCoursesIcons: assests.businessmanagement,
              LongCoursesName: "BA (Hons) Business Management with Foundation Year",
              LongCoursesSpan: "Year 2 (Level 4) modules",
              LongCoursesList: [
                {LongCoursesInnerList: "The Responsible Business"},
                {LongCoursesInnerList: "he Innovative Business"},
                {LongCoursesInnerList: "The Sustainable Business"},
                {LongCoursesInnerList: "The Digital Business"}
              ],
          },
          {
              id:3,
              LongCoursesIcons: assests.businessmanagement,
              LongCoursesName: "BA (Hons) Business Management with Foundation Year",
              LongCoursesSpan: "Year 3 (Level 5) modules",
              LongCoursesList: [
                {LongCoursesInnerList: "Customer Acquisition and Retention"},
                {LongCoursesInnerList: "The Professional Manager and Leadership"},
                {LongCoursesInnerList: "Operations and Project Planning Managing Finance and Accounts"}
              ],
          },
          {
            id:4,
            LongCoursesIcons: assests.businessmanagement,
            LongCoursesName: "BA (Hons) Business Management with Foundation Year",
            LongCoursesSpan: "Year 4 (Level 6) modules",
            LongCoursesList: [
                {LongCoursesInnerList: "The Strategic Business"},
                {LongCoursesInnerList: "Organizational Behaviour"},
                {LongCoursesInnerList: "The Professional Project"},
                {LongCoursesInnerList: "The Business Communicator"}
            ],
        }
      ]
  return (
    <>
        <BreadcrumbDesign 
            BreadCrumbImg={assests.BreadcrumbImage} 
            BreadcrumbPara={'Lorem ipsum dolor sit amet consectetur adipisicing elit.'} BreacrumbHeading={`BA (Hons) Business Management with foundation year`}
        />
        <div className='ptb60'>
            <div className="container">
                <div className="grid grid-cols-12 gap-x-5">
                  <div className="col-span-12 md:col-span-9">
                    <div className="grid grid-cols-12 gap-x-5">
                      {LongTermsMaping.map((val)=>(
                        <div className="col-span-12 md:col-span-6 mb20" key={val.id}>
                          <LongTermsDetailsCard 
                            icon={val.LongCoursesIcons} 
                            name={val.LongCoursesName}
                            year={val.LongCoursesSpan}
                            modules={val.LongCoursesList? val.LongCoursesList.map((listval, index)=>(
                              <li key={index} className='list-decimal'>{listval.LongCoursesInnerList}</li>
                            )) : null}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="col-span-12 md:col-span-3">
                      <ApplyNowForm/>
                  </div>
                </div>
            </div>
        </div>
    </>
  )
}

export default BusinessManagementFoundationYear
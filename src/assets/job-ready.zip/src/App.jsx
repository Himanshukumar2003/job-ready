import React from 'react'
import { createBrowserRouter, Outlet, RouterProvider } from 'react-router-dom'
import HomeLayout from './Components/HomeLayout'
import Error from './Components/Error'
import Navbar from './Components/NavFoot/Navbar'
import Footer from './Components/NavFoot/Footer'
import CoursesCard from './Components/Courses/CoursesCard'
import About from './Components/About/AboutDesign'
import LongTermsCourses from './Components/LongTerms/LongTermsCourses'
import BusinessManagementFoundationYear from './Components/LongTerms/BusinessManagementFoundationYear'
import ComputerScienceFoundationYear from './Components/LongTerms/ComputerScienceFoundationYear'
import HealthandSocialCareFoundationYear from './Components/LongTerms/HealthandSocialCareFoundationYear'

const Layout = () =>(
    <div>
      <Navbar/>
      <Outlet/>
      <Footer/>
    </div>
)

const App = () => {
  const router = createBrowserRouter ([
    {
      path: '/',
      element: <Layout/>,
      errorElement: <Error/>,
      children: [
        {
          path: '/',
          element: <HomeLayout/>
        },
        {
          path: '/about',
          element: <About/>
        },
        {
          path: '/courses',
          element: <CoursesCard/>
        },
        {
          path: '/long-terms',
          element: <LongTermsCourses/>
        },
        {
          path: "/long-terms/ba-hons-business-management-with-foundation-year",
          element: <BusinessManagementFoundationYear/>
        },
        {
          path: "/long-terms/bsc-hons-computer-science-with-foundation-year",
          element: <ComputerScienceFoundationYear/>
        },
        {
          path: "/long-terms/bsc-hons-health-and-social-care-with-foundation-year",
          element: <HealthandSocialCareFoundationYear/>
        }
      ]
    }
  ])
  return (
    <RouterProvider router={router}/>
  )
}

export default App